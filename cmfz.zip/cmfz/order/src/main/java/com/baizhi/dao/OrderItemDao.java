package com.baizhi.dao;

import com.baizhi.entity.OrderItem;
import tk.mybatis.mapper.common.Mapper;

public interface OrderItemDao extends Mapper<OrderItem> {
}
