//package com.baizhi;
//
//import com.aliyuncs.CommonRequest;
//import com.aliyuncs.CommonResponse;
//import com.aliyuncs.DefaultAcsClient;
//import com.aliyuncs.IAcsClient;
//import com.aliyuncs.exceptions.ClientException;
//import com.aliyuncs.exceptions.ServerException;
//import com.aliyuncs.http.MethodType;
//import com.aliyuncs.profile.DefaultProfile;
//import com.baizhi.dao.AdminDao;
//import com.baizhi.entity.Admin;
//import io.goeasy.GoEasy;
//import org.apache.ibatis.session.RowBounds;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//import tk.mybatis.mapper.entity.Example;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.UUID;
//
//@SpringBootTest
//@RunWith(SpringRunner.class)
//public class CmfzApplicationTests {
//    @Autowired
//    AdminDao adminDao;
//    @Test
//    public void contextLoads() {
//        // 查所有
//        //List<Admin> admins = adminDao.selectAll();
//        // 查一个对象
//        // 实体类中的属性 会作为搜索字段体现在sql语句中
//        //Admin admin = new Admin(null,"admin","admin");
//        //Admin admin1 = adminDao.selectOne(admin);
//        //System.out.println(admin1);
//        //System.out.println(admins);
//        // 根据主键查询
////        Admin admin2 = adminDao.selectByPrimaryKey("1");
////        System.out.println(admin2);
//        // 根据查询条件返回找到的信息数量
//        //adminDao.selectCount(null);
//        // 根据条件查询多个或一个对象
//        //adminDao.select(null);
//        // 分页查询
//        //List<Admin> admins = adminDao.selectByRowBounds(null, new RowBounds(2, 2));
//        //System.out.println(admins);
//        // 特定条件查询
//        Example example = new Example(Admin.class);
//        example.and().andIn("username", Arrays.asList("Rxx","Rx"));
//        List<Admin> admins1 = adminDao.selectByExample(example);
//        System.out.println(admins1);
//    }
//    @Test
//    public void testAdd(){
//        Admin baobeier = new Admin(UUID.randomUUID().toString(), "Baobeier", "123123");
//        adminDao.insert(baobeier);
//        //adminDao.insertSelective(baobeier);
//    }
//    @Test
//    public void testUpdate(){
//        Admin admin = new Admin("2", "任祥鑫", null);
//        adminDao.updateByPrimaryKeySelective(admin);
//    }
//    @Test
//    public void testDel(){
//        //Admin admin = new Admin();
//        //admin.setUsername("Rx");
//        // 根据条件删除
//        //adminDao.delete(admin);
//        // 根据主键删除
//        //adminDao.deleteByPrimaryKey("4");
//        // 特定条件删除
//        //adminDao.deleteByExample(null);
//        //adminDao.deleteByIdList(Arrays.asList("4","5","6"));
//        Admin admin1 = new Admin(UUID.randomUUID().toString(), "Rxx", "962482");
//        Admin admin2 = new Admin(UUID.randomUUID().toString(), "Rxx", "962482");
//        Admin admin3 = new Admin(UUID.randomUUID().toString(), "Rxx", "962482");
//        List<Admin> admins = Arrays.asList(admin1,admin2,admin3);
//        adminDao.insertList(admins);
//    }
//    @Test
//    public void testgoeasy(){
//        GoEasy goEasy = new GoEasy( "http://rest-hangzhou.goeasy.io", "BC-2cee62d1b57b4c5c9d23032665b66aef");
//        goEasy.publish("cmfz", "Hello, GoEasy!");
//    }
//    @Test
//    public void testSms(){
//        DefaultProfile profile = DefaultProfile.getProfile("cn-hangzhou", "LTAIN3Z8o6oI2CJg", "p0NgUtaHSLe6b7qdzSqMHI7YIpGGHg");
//        IAcsClient client = new DefaultAcsClient(profile);
//        CommonRequest request = new CommonRequest();
//        request.setMethod(MethodType.POST);
//        request.setDomain("dysmsapi.aliyuncs.com");
//        request.setVersion("2017-05-25");
//        request.setAction("SendSms");
//        request.putQueryParameter("RegionId", "cn-hangzhou");
//        request.putQueryParameter("PhoneNumbers", "18335036013");
//        request.putQueryParameter("SignName", "wquifg");
//        request.putQueryParameter("TemplateCode", "SMS_149391189");
//        request.putQueryParameter("TemplateParam", "{\"code\":\"1234\"}");
//        try {
//            CommonResponse response = client.getCommonResponse(request);
//            System.out.println(response.getData());
//        } catch (ServerException e) {
//            e.printStackTrace();
//        } catch (ClientException e) {
//            e.printStackTrace();
//        }
//    }
//}
