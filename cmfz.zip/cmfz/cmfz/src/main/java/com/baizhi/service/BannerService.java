package com.baizhi.service;

import java.util.Map;

public interface BannerService {
    Map getAllBanners(Integer page,Integer rows);
}
