package com.baizhi.controller;

import com.baizhi.dao.AdminDao;
import com.baizhi.entity.Admin;
import org.apache.jasper.security.SecurityUtil;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("admin")
public class AdminController {
    @Autowired
    AdminDao adminDao;
    @RequestMapping("login")
    public Map login(String username,String password){
        Subject subject = SecurityUtils.getSubject();
        // 1. 创建需要返回的Map集合
        HashMap hashMap = new HashMap();
        // 2. 构建查询条件
        UsernamePasswordToken usernamePasswordToken = new UsernamePasswordToken(username, password);
        try {
            subject.login(usernamePasswordToken);
        }catch (UnknownAccountException exception){
            hashMap.put("status",400);
            hashMap.put("msg","该用户不存在");
            return hashMap;
        }catch (IncorrectCredentialsException exception){
            hashMap.put("status",400);
            hashMap.put("msg","密码错误");
            return hashMap;
        }
        hashMap.put("status",200);
        // 5. 返回集合
        return hashMap;
    }
    @RequestMapping("logout")
    public void logout(){
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
    }
}
