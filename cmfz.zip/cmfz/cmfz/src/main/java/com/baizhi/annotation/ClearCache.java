package com.baizhi.annotation;

public @interface ClearCache {
}
