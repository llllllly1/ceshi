package com.baizhi.annotation;

public @interface AddOrSelectCache {
}
