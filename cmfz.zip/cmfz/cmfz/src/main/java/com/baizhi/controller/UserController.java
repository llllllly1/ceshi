package com.baizhi.controller;

import com.alibaba.druid.support.json.JSONUtils;
import com.baizhi.dao.UserDao;
import com.baizhi.entity.User;
import com.baizhi.util.SmsUtil;
import io.goeasy.GoEasy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.concurrent.TimeUnit;

@RequestMapping("user")
@RestController
public class UserController {
    @Autowired
    RedisTemplate redisTemplate;
    @Autowired
    UserDao userDao;
    @RequestMapping("showUserTime")
    public Map showUserTime(){
        HashMap hashMap = new HashMap();
        ArrayList manList = new ArrayList();
        manList.add(userDao.queryUserByTime("0",1));
        manList.add(userDao.queryUserByTime("0",7));
        manList.add(userDao.queryUserByTime("0",30));
        manList.add(userDao.queryUserByTime("0",365));
        ArrayList womenList = new ArrayList();
        womenList.add(userDao.queryUserByTime("1",1));
        womenList.add(userDao.queryUserByTime("1",7));
        womenList.add(userDao.queryUserByTime("1",30));
        womenList.add(userDao.queryUserByTime("1",365));
        hashMap.put("man",manList);
        hashMap.put("women",womenList);
        return hashMap;
    }
    @RequestMapping("addUser")
    public void addUser(){
        User user = new User();
        user.setId(UUID.randomUUID().toString());
        user.setSex("0");
        user.setLocation("河南");
        user.setRigestDate(new Date());
        userDao.insert(user);
        GoEasy goEasy = new GoEasy( "http://rest-hangzhou.goeasy.io", "BC-2cee62d1b57b4c5c9d23032665b66aef");
        Map map = showUserTime();
        String s = JSONUtils.toJSONString(map);
        System.out.println(s);
        goEasy.publish("cmfz", s);
    }
    @RequestMapping("login")
    public Map login(String phone,String password){
        HashMap hashMap = new HashMap();
        hashMap.put("status","200");
        hashMap.put("user",new User());
        return hashMap;
    }
    @RequestMapping("sendCode")
    public Map sendCode(String phone){
        String s = UUID.randomUUID().toString();
        String code = s.substring(0, 3);
        SmsUtil.send(phone,code);
        // 将验证码保存值Redis  Key phone_186XXXX Value code 1分钟有效
        redisTemplate.opsForValue().set("phone_"+phone,code,60, TimeUnit.SECONDS);
        HashMap hashMap = new HashMap();
        hashMap.put("status","200");
        hashMap.put("message","短信发送成功");
        return hashMap;
    }
}
